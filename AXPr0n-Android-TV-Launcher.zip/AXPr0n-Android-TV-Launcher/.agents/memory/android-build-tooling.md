---
name: Android build tooling
description: Environment note for validating native Android projects in this workspace
---

Native Android source can be authored in this workspace, but the default container may not include Java 17, Gradle, or the Android SDK. Treat static source/XML checks as partial verification and use Android Studio or a CI runner with the Android toolchain for the final APK build.

**Why:** The Android TV project could not run an APK compile locally because the required native toolchain was absent.

**How to apply:** Before promising a locally verified APK, check for Java, Gradle, and Android SDK availability; otherwise be explicit that the source is ready for Android Studio/CI compilation.