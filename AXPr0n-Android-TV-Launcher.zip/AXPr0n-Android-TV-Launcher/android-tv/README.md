# AXPr0n Android TV

AXPr0n is a focused Android TV / Google TV shortcut launcher. The home screen presents seven editable website shortcuts in a two-column D-pad grid. A selected shortcut opens in the app's embedded WebView; the app does not launch an external browser.

## Build

1. Open the `android-tv` directory in Android Studio Ladybug or newer.
2. Allow Gradle to sync. The project uses Android Gradle Plugin 8.6.1, Kotlin 2.0.21, and Java 17.
3. Select the `app` configuration and build either:
   - `Build > Build APK(s)` in Android Studio, or
   - `gradle assembleDebug` from this directory with Gradle 8.7+ installed.
4. Install the generated debug APK on an Android TV / Google TV device:

   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

The release build is minified and uses the standard Android optimized ProGuard file. Configure signing in `app/build.gradle.kts` before distributing a release APK.

## Build from a phone with GitHub Actions

This repository includes `.github/workflows/build-android-apk.yml`, so you can build the debug APK from a phone browser without installing Android Studio.

1. Put this project in a GitHub repository. The repository should contain the `android-tv/` directory and the `.github/workflows/` directory.
2. Open the repository on GitHub and select the **Actions** tab.
3. Select **Build Android TV APK**.
4. Tap **Run workflow**, then tap the green **Run workflow** button.
5. When the job finishes, open the completed run and scroll to **Artifacts**.
6. Download `AXPr0n-debug-apk`, unzip it on your phone, and install `app-debug.apk` on the TV.

The workflow installs Java 17, Android SDK 35, and Gradle 8.7 automatically. It produces a debug-signed APK for personal installation; no signing keys or secrets are needed.

## Project notes

- `app/src/main/java/com/axpr0n/tv/Shortcut.kt` is the single editable shortcut catalog. Keep the list order to control the D-pad grid order.
- Website icons are fetched from Google's favicon endpoint in the background. Every tile starts with a generated letter fallback, so offline or failed icon requests never produce a broken tile.
- Only `INTERNET` permission is requested.
- WebView JavaScript, DOM storage, cookies, normal links, forms, and in-page history are enabled. Unsupported URL schemes are blocked in-app.
- Back first navigates WebView history, then returns to the shortcut grid, then exits from the grid.
- This is a link-launcher app. Any content displayed in the WebView is controlled by the destination websites; users should follow the laws and age requirements applicable to their location.