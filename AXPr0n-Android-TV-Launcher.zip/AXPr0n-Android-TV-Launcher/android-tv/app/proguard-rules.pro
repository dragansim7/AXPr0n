# AXPr0n has no reflection-heavy application code. Keep this file for
# future WebView bridge or SDK rules if the project grows.