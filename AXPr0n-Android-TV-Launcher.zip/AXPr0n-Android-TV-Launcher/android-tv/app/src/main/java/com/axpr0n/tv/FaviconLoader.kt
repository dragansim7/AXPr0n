package com.axpr0n.tv

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object FaviconLoader {
    private val executor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun load(shortcut: Shortcut, onLoaded: (Bitmap) -> Unit) {
        executor.execute {
            val bitmap = runCatching {
                val connection = URL(shortcut.faviconUrl).openConnection() as HttpURLConnection
                connection.connectTimeout = 4_000
                connection.readTimeout = 4_000
                connection.instanceFollowRedirects = true
                connection.useCaches = true
                connection.inputStream.use(BitmapFactory::decodeStream).also {
                    connection.disconnect()
                }
            }.getOrNull() ?: return@execute

            mainHandler.post { onLoaded(bitmap) }
        }
    }
}