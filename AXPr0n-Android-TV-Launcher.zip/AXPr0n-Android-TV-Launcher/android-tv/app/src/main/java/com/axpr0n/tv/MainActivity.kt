package com.axpr0n.tv

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var homeScreen: View
    private lateinit var browserScreen: View
    private lateinit var shortcutsGrid: RecyclerView
    private lateinit var webView: WebView
    private lateinit var browserTitle: TextView
    private lateinit var progress: ProgressBar
    private lateinit var errorPanel: View
    private lateinit var errorMessage: TextView
    private lateinit var browserBack: ImageButton
    private lateinit var reloadButton: ImageButton

    private var focusedIndex = 0
    private var currentShortcut: Shortcut? = null
    private var currentUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_main)

        homeScreen = findViewById(R.id.home_screen)
        browserScreen = findViewById(R.id.browser_screen)
        shortcutsGrid = findViewById(R.id.shortcuts_grid)
        webView = findViewById(R.id.web_view)
        browserTitle = findViewById(R.id.browser_title)
        progress = findViewById(R.id.page_progress)
        errorPanel = findViewById(R.id.error_panel)
        errorMessage = findViewById(R.id.error_message)
        browserBack = findViewById(R.id.browser_back)
        reloadButton = findViewById(R.id.reload_button)

        setupHome()
        setupBrowser()
        showHome()
    }

    private fun setupHome() {
        val layoutManager = GridLayoutManager(this, 2)
        shortcutsGrid.layoutManager = layoutManager
        shortcutsGrid.adapter = ShortcutAdapter(
            onShortcutSelected = { index, shortcut ->
                focusedIndex = index
                openBrowser(shortcut)
            },
            onShortcutFocused = { focusedIndex = it },
        )
        shortcutsGrid.setHasFixedSize(false)
        shortcutsGrid.itemAnimator = null
        shortcutsGrid.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupBrowser() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = true
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.setOnKeyListener { _, keyCode, event ->
            if (
                event.action == KeyEvent.ACTION_DOWN &&
                keyCode == KeyEvent.KEYCODE_DPAD_UP &&
                !webView.canScrollVertically(-1)
            ) {
                browserBack.requestFocus()
                true
            } else {
                false
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest,
            ): Boolean {
                return handleUrl(request.url)
            }

            @Deprecated("Deprecated in API 24")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                handleUrl(Uri.parse(url))

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                currentUrl = url
                progress.visibility = View.VISIBLE
                errorPanel.visibility = View.GONE
                updateBrowserTitle(url)
                updateNavigationButton()
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
                updateBrowserTitle(view.title?.takeIf { it.isNotBlank() } ?: url)
                updateNavigationButton()
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError,
            ) {
                if (request.isForMainFrame) {
                    showError("Couldn’t load this page. Check the connection and try again.")
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView, title: String?) {
                if (!title.isNullOrBlank()) updateBrowserTitle(title)
            }
        }

        browserBack.setOnClickListener {
            if (webView.canGoBack()) webView.goBack() else showHome()
        }
        reloadButton.setOnClickListener {
            errorPanel.visibility = View.GONE
            webView.reload()
        }
        findViewById<Button>(R.id.retry_button).setOnClickListener {
            errorPanel.visibility = View.GONE
            currentUrl?.let(webView::loadUrl)
        }
        findViewById<Button>(R.id.return_home_button).setOnClickListener { showHome() }
    }

    private fun handleUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase()
        return if (scheme == "http" || scheme == "https") {
            false
        } else {
            showError("This link type is not supported inside the app.")
            true
        }
    }

    private fun openBrowser(shortcut: Shortcut) {
        currentShortcut = shortcut
        currentUrl = shortcut.url
        homeScreen.visibility = View.GONE
        browserScreen.visibility = View.VISIBLE
        errorPanel.visibility = View.GONE
        progress.visibility = View.VISIBLE
        browserTitle.text = shortcut.domain
        updateNavigationButton()
        webView.requestFocus()
        webView.loadUrl(shortcut.url)
    }

    private fun showHome() {
        webView.stopLoading()
        homeScreen.visibility = View.VISIBLE
        browserScreen.visibility = View.GONE
        progress.visibility = View.GONE
        errorPanel.visibility = View.GONE
        shortcutsGrid.post {
            shortcutsGrid.scrollToPosition(focusedIndex)
            val holder = shortcutsGrid.findViewHolderForAdapterPosition(focusedIndex)
            if (holder?.itemView?.requestFocus() != true) {
                shortcutsGrid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
            }
        }
    }

    private fun showError(message: String) {
        progress.visibility = View.GONE
        errorMessage.text = message
        errorPanel.visibility = View.VISIBLE
        findViewById<Button>(R.id.retry_button).requestFocus()
    }

    private fun updateNavigationButton() {
        browserBack.setImageResource(
            if (webView.canGoBack()) R.drawable.ic_arrow_back else R.drawable.ic_home,
        )
        browserBack.contentDescription = getString(
            if (webView.canGoBack()) R.string.back_description else R.string.home_description,
        )
    }

    private fun updateBrowserTitle(value: String) {
        browserTitle.text = value
            .replace(Regex("^https?://"), "")
            .substringBefore("/")
            .ifBlank { currentShortcut?.domain ?: getString(R.string.browser_title) }
    }

    override fun onBackPressed() {
        if (browserScreen.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack() else showHome()
        } else {
            super.onBackPressed()
        }
    }
}