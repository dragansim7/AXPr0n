package com.axpr0n.tv

data class Shortcut(
    val url: String,
    val label: String,
    val domain: String,
) {
    val faviconUrl: String
        get() = "https://www.google.com/s2/favicons?domain=$domain&sz=128"
}

object ShortcutCatalog {
    val all = listOf(
        Shortcut("https://xhamster.com/", "xHamster", "xhamster.com"),
        Shortcut("https://spankbang.com/", "SpankBang", "spankbang.com"),
        Shortcut("https://porndoe.com/", "PornDoe", "porndoe.com"),
        Shortcut("https://porndig.com/", "PornDig", "porndig.com"),
        Shortcut("https://m.hqporner.com/", "HQPorner", "hqporner.com"),
        Shortcut("https://eporner.com/", "ePorner", "eporner.com"),
        Shortcut("https://porntrex.com/", "PornTrex", "porntrex.com"),
    )
}