package com.axpr0n.tv

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ShortcutAdapter(
    private val onShortcutSelected: (Int, Shortcut) -> Unit,
    private val onShortcutFocused: (Int) -> Unit,
) : RecyclerView.Adapter<ShortcutAdapter.TileHolder>() {
    private val shortcuts = ShortcutCatalog.all

    class TileHolder(val tile: ShortcutTileView) : RecyclerView.ViewHolder(tile)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TileHolder =
        TileHolder(ShortcutTileView(parent.context))

    override fun onBindViewHolder(holder: TileHolder, position: Int) {
        val shortcut = shortcuts[position]
        holder.tile.bind(shortcut)
        holder.tile.onFocusChanged = { focused ->
            if (focused) onShortcutFocused(position)
        }
        holder.tile.setOnClickListener {
            onShortcutSelected(position, shortcut)
        }
    }

    override fun getItemCount(): Int = shortcuts.size
}