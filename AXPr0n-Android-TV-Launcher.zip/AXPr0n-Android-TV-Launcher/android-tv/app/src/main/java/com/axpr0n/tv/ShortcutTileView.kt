package com.axpr0n.tv

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class ShortcutTileView(context: Context) : FrameLayout(context) {
    private val iconView = ImageView(context)
    private val fallbackView = TextView(context)
    private val labelView = TextView(context)
    private var boundUrl: String? = null
    var onFocusChanged: ((Boolean) -> Unit)? = null

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        clipChildren = false
        clipToPadding = false
        setPadding(dp(16), dp(16), dp(16), dp(16))
        updateBackground(false)

        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }

        val iconSize = dp(76)
        val iconContainer = FrameLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
        }

        iconView.apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(iconSize, iconSize)
        }
        fallbackView.apply {
            gravity = Gravity.CENTER
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(53, 73, 61))
            }
            layoutParams = FrameLayout.LayoutParams(iconSize, iconSize)
        }
        iconContainer.addView(fallbackView)
        iconContainer.addView(iconView)
        content.addView(iconContainer)

        labelView.apply {
            setTextColor(Color.rgb(242, 244, 243))
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT,
            ).apply {
                topMargin = dp(16)
            }
        }
        content.addView(labelView)
        addView(
            content,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT),
        )

        setOnFocusChangeListener { _, hasFocus ->
            updateBackground(hasFocus)
            animate()
                .scaleX(if (hasFocus) 1.06f else 1f)
                .scaleY(if (hasFocus) 1.06f else 1f)
                .setDuration(180)
                .start()
            elevation = dp(if (hasFocus) 10 else 2).toFloat()
            onFocusChanged?.invoke(hasFocus)
        }
    }

    fun bind(shortcut: Shortcut) {
        boundUrl = shortcut.url
        fallbackView.text = shortcut.label.firstOrNull()?.uppercase() ?: "?"
        labelView.text = shortcut.label
        iconView.setImageDrawable(null)
        iconView.visibility = View.GONE
        fallbackView.visibility = View.VISIBLE

        FaviconLoader.load(shortcut) { bitmap ->
            if (boundUrl == shortcut.url) {
                iconView.setImageBitmap(bitmap)
                iconView.visibility = View.VISIBLE
                fallbackView.visibility = View.GONE
            }
        }
    }

    private fun updateBackground(focused: Boolean) {
        background = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat()
            setColor(
                if (focused) Color.rgb(31, 39, 35) else Color.rgb(27, 31, 33),
            )
            setStroke(
                if (focused) dp(4) else dp(1),
                if (focused) Color.rgb(121, 185, 138) else Color.rgb(50, 57, 59),
            )
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = when (MeasureSpec.getMode(widthMeasureSpec)) {
            MeasureSpec.EXACTLY, MeasureSpec.AT_MOST -> MeasureSpec.getSize(widthMeasureSpec)
            else -> dp(220)
        }
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
        )
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun Float.roundToInt(): Int = kotlin.math.round(this).toInt()
}